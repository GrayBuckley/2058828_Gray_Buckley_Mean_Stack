Repo URL: https://github.com/GrayBuckley/2058828_Gray_Buckley_Mean_Stack.git
Project name: MyPortfolio
Files:
2058828_Gray_Buckley_Mean_Stack\Phase 2\portfolio\register.html: page where new accounts can be created
2058828_Gray_Buckley_Mean_Stack\Phase 2\portfolio\register.js: js used by register.html
2058828_Gray_Buckley_Mean_Stack\Phase 2\portfolio\login.html: page where existing account can be logged into
2058828_Gray_Buckley_Mean_Stack\Phase 2\portfolio\login.js: js used by login.html
2058828_Gray_Buckley_Mean_Stack\Phase 2\portfolio\landing.html: page where contacts can be created and viewed
2058828_Gray_Buckley_Mean_Stack\Phase 2\portfolio\landing.js: js used by landing.html