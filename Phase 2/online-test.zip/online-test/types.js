"use strict";
exports.__esModule = true;
exports.isTestRequest = exports.isGradeRequest = void 0;
function isGradeRequest(request) {
    return request.requestType === "grade";
}
exports.isGradeRequest = isGradeRequest;
function isTestRequest(request) {
    return request.requestType === "test";
}
exports.isTestRequest = isTestRequest;
