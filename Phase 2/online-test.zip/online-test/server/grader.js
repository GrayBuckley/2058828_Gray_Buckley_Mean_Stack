"use strict";
exports.__esModule = true;
exports.gradeSubmission = void 0;
function gradeQuestion(submission, key) {
    return {
        submitted: submission,
        key: key,
        correct: submission === key
    };
}
function gradeSubmission(submission, key) {
    var denom = key.answers.length;
    var num = 0;
    var questionReports = [];
    for (var i = 0; i < denom; i++) {
        var thisReport = gradeQuestion(submission[i], key.answers[i]);
        questionReports.push(thisReport);
        if (thisReport.correct)
            num++;
    }
    return {
        answers: questionReports,
        totalCorrect: num,
        passed: (num / denom) >= key.minPass
    };
}
exports.gradeSubmission = gradeSubmission;
