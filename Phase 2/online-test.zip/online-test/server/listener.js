"use strict";
exports.__esModule = true;
var grader = require("./grader");
var types = require("../types");
var http = require('http');
var url = require('url');
var tests = require('./tests.json');
var config = require('../config.json');
http.createServer(function (req, res) {
    var request = JSON.parse(url.parse(req.url, true).query.request);
    console.log(request);
    if (request.testID >= tests.length || request.testID < 0) {
        requestFail(res);
        return;
    }
    res.writeHead(200);
    var response = "";
    if (types.isTestRequest(request)) {
        response = JSON.stringify(tests[request.testID].questions);
    }
    else {
        var gRequest = request;
        var report = grader.gradeSubmission(gRequest.submission, tests[request.testID].answerKey);
        response = JSON.stringify(report);
    }
    res.end(response);
}).listen(config.port);
function requestFail(res) {
    res.writeHead(404);
    res.end();
}
