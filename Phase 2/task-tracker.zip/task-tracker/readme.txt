Repo URL: https://github.com/GrayBuckley/2058828_Gray_Buckley_Mean_Stack.git
Project name: Task Tracker
Files:
2058828_Gray_Buckley_Mean_Stack\Phase 2\portfolio\index.html : task tracker page and scripts to make it work
2058828_Gray_Buckley_Mean_Stack\Phase 2\portfolio\manifest.json : manifest for PWA
2058828_Gray_Buckley_Mean_Stack\Phase 2\portfolio\service-worker.js : script for PWA service worker
