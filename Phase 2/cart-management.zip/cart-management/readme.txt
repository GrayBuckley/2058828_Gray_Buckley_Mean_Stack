Repo URL: https://github.com/GrayBuckley/2058828_Gray_Buckley_Mean_Stack.git
Project name: Cart Management
Files:
2058828_Gray_Buckley_Mean_Stack\Phase 2\cart-management\storefront.html: page where items can be added to cart
2058828_Gray_Buckley_Mean_Stack\Phase 2\cart-management\checkout.html: page that displays cart and total
2058828_Gray_Buckley_Mean_Stack\Phase 2\cart-management\styles.css: styles for tables on both pages
2058828_Gray_Buckley_Mean_Stack\Phase 2\cart-management\scripts.ts: typescript functions to update and display cart
2058828_Gray_Buckley_Mean_Stack\Phase 2\cart-management\scripts.js: compiled version of scripts.ts
2058828_Gray_Buckley_Mean_Stack\Phase 2\cart-management\Makefile: Makefile to simplify compilation