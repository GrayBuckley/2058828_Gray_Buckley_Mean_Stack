Repo URL: https://github.com/GrayBuckley/2058828_Gray_Buckley_Mean_Stack.git
Project name: Angular Application on Github
Files:
2058828_Gray_Buckley_Mean_Stack\Phase 1\angular-app\readme.txt