Repo URL: https://github.com/GrayBuckley/2058828_Gray_Buckley_Mean_Stack.git
Project name: Design Shell
Files:
2058828_Gray_Buckley_Mean_Stack\Phase 1\design-shell\demo.html : HTML content
2058828_Gray_Buckley_Mean_Stack\Phase 1\design-shell\styles.css : CSS styles and class