Repo URL: https://github.com/GrayBuckley/2058828_Gray_Buckley_Mean_Stack.git
Project name: Simply Blogging
Files:
2058828_Gray_Buckley_Mean_Stack\Phase 1\simply-blogging\blogs.html : base HTML page
2058828_Gray_Buckley_Mean_Stack\Phase 1\simply-blogging\scripts.js : JS scripts to add blogs