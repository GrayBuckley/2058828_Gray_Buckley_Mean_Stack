Repo URL: https://github.com/GrayBuckley/2058828_Gray_Buckley_Mean_Stack.git
Project name: Budget Planner
Files:
2058828_Gray_Buckley_Mean_Stack\Phase 1\budget-planner\index.html : HTML home page
2058828_Gray_Buckley_Mean_Stack\Phase 1\budget-planner\manager.html : HTML Program Manager Page
2058828_Gray_Buckley_Mean_Stack\Phase 1\budget-planner\teams.html : HTML Finance Teams Page
2058828_Gray_Buckley_Mean_Stack\Phase 1\budget-planner\styles.css : Sitewide CSS
2058828_Gray_Buckley_Mean_Stack\Phase 1\budget-planner\scripts.js : Methods used by manager.html and teams.html