var serverURL = "http:127.0.0.1:8080/";
function addClick() {
    var eid = document.getElementById("eidInput").value;
    var tid = document.getElementById("tidInput").value;
    var taskDesc = document.getElementById("tdescInput").value;
    var due = document.getElementById("deadlineInput").value;
    fetch(serverURL + "add?eid=" + eid + "&tid=" + tid + "&task=" + taskDesc + "&due=" + due);
    listClick();
}
function deleteClick() {
    var tid = document.getElementById("tidDelete").value;
    fetch(serverURL + "delete?tid=" + tid);
    listClick();
}
function listClick() {
    clearTable(document.getElementById("table"));
    fetch(serverURL + "get").then(function (res) { return getRecieved(res); });
}
function getRecieved(res) {
    res.blob().then(function (blob) {
        blob.text().then(function (txt) {
            var a = JSON.parse(txt);
            a.forEach(function (t) {
                var row = document.createElement("tr");
                var eidD = document.createElement("td");
                var tidD = document.createElement("td");
                var descD = document.createElement("td");
                var dueD = document.createElement("td");
                eidD.innerText = t.empID;
                tidD.innerText = t.taskID;
                descD.innerText = t.task;
                dueD.innerText = t.deadline;
                row.appendChild(eidD);
                row.appendChild(tidD);
                row.appendChild(descD);
                row.appendChild(dueD);
                document.getElementById("table").appendChild(row);
            });
        });
    });
}
function clearTable(table) {
    var rows = table.rows;
    var i = rows.length;
    while (--i)
        rows[i].parentNode.removeChild(rows[i]);
}
