"use strict";
exports.__esModule = true;
exports.removeTask = exports.pushTask = exports.newTask = void 0;
function newTask(empID, taskID, task, deadline) {
    return {
        empID: empID,
        taskID: taskID,
        task: task,
        deadline: deadline
    };
}
exports.newTask = newTask;
function conflictingTask(l, r) {
    return l.taskID == r.taskID;
}
function pushTask(log, t) {
    var conflict = false;
    log.forEach(function (checkT) {
        conflict = conflict || conflictingTask(t, checkT);
    });
    if (!conflict)
        log.push(t);
}
exports.pushTask = pushTask;
function removeTask(log, id) {
    var found = null;
    for (var i = 0; i < log.length; i++)
        if (log[i].taskID == id)
            found = i;
    if (found !== null)
        log.splice(found, 1);
}
exports.removeTask = removeTask;
