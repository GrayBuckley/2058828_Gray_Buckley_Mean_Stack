"use strict";
exports.__esModule = true;
exports.removeRecord = exports.addRecord = exports.logInit = exports.readLog = void 0;
var fs = require('fs');
var task = require("../task");
var logPath = "./log.json";
function readLog() {
    return JSON.parse(fs.readFileSync(logPath));
}
exports.readLog = readLog;
function writeLog(log) {
    fs.writeFileSync(logPath, JSON.stringify(log));
}
function logInit() {
    try {
        fs.accessSync(logPath);
    }
    catch (_a) {
        fs.writeFileSync(logPath, JSON.stringify([]));
    }
}
exports.logInit = logInit;
function addRecord(t) {
    var log = readLog();
    task.pushTask(log, t);
    writeLog(log);
}
exports.addRecord = addRecord;
function removeRecord(id) {
    var log = readLog();
    task.removeTask(log, id);
    writeLog(log);
}
exports.removeRecord = removeRecord;
