"use strict";
exports.__esModule = true;
var file = require("./fileIO");
var task_1 = require("../task");
var http = require("http");
var url = require("url");
var listener = function (req, res) {
    res.writeHead(200, { 'Access-Control-Allow-Origin': '*' });
    var urlObj = url.parse(req.url, true);
    var queryObject = urlObj.query;
    //console.log(urlObj.pathname);
    if (urlObj.pathname == "/add") {
        var t = task_1.newTask(queryObject.eid, queryObject.tid, queryObject.task, queryObject.due);
        file.addRecord(t);
    }
    if (urlObj.pathname == "/delete")
        file.removeRecord(queryObject.tid);
    if (urlObj.pathname == "/get") {
        res.write(JSON.stringify(file.readLog()));
    }
    res.end();
};
file.logInit();
var server = http.createServer(listener);
server.listen(8080);
