"use strict";
exports.__esModule = true;
exports.addRecord = exports.logInit = void 0;
var fs = require('fs');
var logPath = "./log.json";
function readLog() {
    return JSON.parse(fs.readFileSync(logPath));
}
function writeLog(log) {
    fs.writeFileSync(logPath, JSON.stringify(log));
}
function logInit() {
    try {
        fs.accessSync(logPath);
    }
    catch (_a) {
        fs.writeFileSync(logPath, JSON.stringify([]));
    }
}
exports.logInit = logInit;
function addRecord(r) {
    var log = readLog();
    log.push(r);
    writeLog(log);
}
exports.addRecord = addRecord;
