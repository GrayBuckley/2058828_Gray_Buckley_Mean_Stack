"use strict";
exports.__esModule = true;
var fileIO = require("./fileIO");
var record_1 = require("./record");
var readline = require('readline');
fileIO.logInit();
var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
var fname;
var lname;
var gender;
var email;
rl.question('First Name: ', function (answer) {
    fname = answer;
    rl.question('Last Name: ', function (answer) {
        lname = answer;
        rl.question('Gender: ', function (answer) {
            gender = answer;
            rl.question('Email: ', function (answer) {
                email = answer;
                var record = record_1.newRecord(fname, lname, gender, email);
                fileIO.addRecord(record);
                rl.close();
            });
        });
    });
});
