"use strict";
exports.__esModule = true;
exports.newRecord = void 0;
function newRecord(firstName, lastName, gender, email) {
    return {
        firstName: firstName,
        lastName: lastName,
        gender: gender,
        email: email,
        date: new Date()
    };
}
exports.newRecord = newRecord;
